
$expectedKBs = @('KB5021234','KB5025678')
$installedKBs = (Get-HotFix).HotFixID
$missing = $expectedKBs | Where-Object { $_ -notin $installedKBs }

if ($missing.Count -gt 0) {
    $msg = "Missing critical KBs: " + ($missing -join ", ")
    Write-EventLog -LogName "Application" -Source "WazuhKBChecker" -EventID 1001 -EntryType Warning -Message $msg
}
