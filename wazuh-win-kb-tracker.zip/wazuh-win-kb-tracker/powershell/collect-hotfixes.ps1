
$kbs = Get-HotFix | Select-Object -Property HotFixID, InstalledOn, Description
$timestamp = Get-Date -Format "yyyy-MM-ddTHH:mm:ss"
$logObj = @{
    timestamp = $timestamp
    hostname  = $env:COMPUTERNAME
    hotfixes  = $kbs
}
$logObj | ConvertTo-Json -Depth 3 | Out-File -FilePath "C:\ProgramData\Wazuh\Logs\hotfixes.json"
